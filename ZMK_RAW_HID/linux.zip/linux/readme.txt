# to run just run this in your terminal (macos/linux)
./zmk-hid-host -c zmk-hid-host.json

# to run just run this in your powershell (windows)
./zmk-hid-host.exe -c zmk-hid-host.json
# or
./zmk-hid-host.silent.exe -c zmk-hid-host.json
